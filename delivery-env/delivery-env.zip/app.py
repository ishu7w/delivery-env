"""
app.py – FastAPI server exposing the DeliveryEnv over HTTP.

Endpoints:
  GET /reset?task=easy|medium|hard  – Reset environment, return initial state
  GET /state                        – Return current state
  POST /step                        – Take an action, return (state, reward, done, info)
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from typing import Any, Dict, Optional

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from tasks.easy import create_task as easy_task
from tasks.medium import create_task as medium_task
from tasks.hard import create_task as hard_task
from env.delivery_env import Action, DeliveryEnv

# ---------------------------------------------------------------------------
# Task registry
# ---------------------------------------------------------------------------

TASK_FACTORIES = {
    "easy": easy_task,
    "medium": medium_task,
    "hard": hard_task,
}

# Global environment — defaults to medium on startup
_env: DeliveryEnv = medium_task()


# ---------------------------------------------------------------------------
# Startup validation – crashes early if any import or task is broken
# ---------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI):
    for name, factory in TASK_FACTORIES.items():
        try:
            env = factory()
            env.reset()
        except Exception as exc:
            raise RuntimeError(f"Startup validation failed for task '{name}': {exc}") from exc
    yield


app = FastAPI(
    title="Smart Last-Mile Delivery API",
    description="OpenEnv RL environment for last-mile delivery optimisation",
    version="1.0.0",
    lifespan=lifespan,
)


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------

class StepRequest(BaseModel):
    delivery_id: int
    vehicle_id: int = 0


class StepResponse(BaseModel):
    state: Dict[str, Any]
    reward: float
    done: bool
    info: Dict[str, Any]


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@app.get("/reset", summary="Reset the environment")
def reset_env(task: Optional[str] = Query(default="medium")) -> JSONResponse:
    """Reset environment to initial state. Pass ?task=easy|medium|hard."""
    global _env
    if task not in TASK_FACTORIES:
        raise HTTPException(status_code=400, detail=f"Unknown task '{task}'. Choose from: {list(TASK_FACTORIES)}")
    _env = TASK_FACTORIES[task]()
    state = _env.reset()
    return JSONResponse(content=state.model_dump(), status_code=200)


@app.get("/state", summary="Get current state")
def get_state() -> JSONResponse:
    """Return the current environment state."""
    state = _env.state()
    return JSONResponse(content=state.model_dump(), status_code=200)


@app.post("/step", summary="Take one step", response_model=StepResponse)
def step_env(req: StepRequest) -> JSONResponse:
    """Execute an action and return (next_state, reward, done, info)."""
    try:
        action = Action(delivery_id=req.delivery_id, vehicle_id=req.vehicle_id)
        next_state, reward, done, info = _env.step(action)
        return JSONResponse(
            content={
                "state": next_state.model_dump(),
                "reward": reward,
                "done": done,
                "info": info,
            },
            status_code=200,
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/", summary="Root")
def root() -> JSONResponse:
    return JSONResponse(content={"status": "ok", "env": "Smart Last-Mile Delivery"}, status_code=200)


@app.get("/health", summary="Health check")
def health() -> JSONResponse:
    return JSONResponse(content={"status": "ok"}, status_code=200)