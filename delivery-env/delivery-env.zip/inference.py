"""
Inference Script – Smart Last-Mile Delivery OpenEnv
===================================
MANDATORY
- Before submitting, ensure the following variables are defined in your environment configuration:
    API_BASE_URL  The API endpoint for the LLM.
    MODEL_NAME    The model identifier to use for inference.
    HF_TOKEN      Your Hugging Face / API key.

- The inference script must be named `inference.py` and placed in the root directory of the project
- Participants must use OpenAI Client for all LLM calls using above variables

STDOUT FORMAT
- The script must emit exactly three line types to stdout, in this order:

    [START] task=<task_name> env=<benchmark> model=<model_name>
    [STEP] step=<n> action=<action_str> reward=<0.00> done=<true|false> error=<msg|null>
    [END] success=<true|false> steps=<n> score=<score> rewards=<r1,r2,...,rn>

Rules:
- One [START] line at episode begin.
- One [STEP] line per step, immediately after env.step() returns.
- One [END] line after episode ends, always emitted (even on exception).
- reward and rewards are formatted to 2 decimal places.
- done and success are lowercase booleans: true or false.
- error is the raw error string, or null if none.
- All fields on a single line with no newlines within a line.
"""

from __future__ import annotations

import json
import math
import os
import sys
import textwrap
import time
from typing import Any, Dict, List, Optional, Tuple

# Ensure project root is on path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from openai import OpenAI

from env.delivery_env import Action, DeliveryEnv, DeliveryStatus, State
from tasks.easy import create_task as easy_task
from tasks.medium import create_task as medium_task
from tasks.hard import create_task as hard_task

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

API_KEY = os.getenv("HF_TOKEN") or os.getenv("API_KEY")
API_BASE_URL = os.getenv("API_BASE_URL") or "https://router.huggingface.co/v1"
MODEL_NAME = os.getenv("MODEL_NAME") or "mistralai/Mistral-Small-24B-Instruct-2501"
BENCHMARK = "delivery_env"

MAX_STEPS_EASY = 200
MAX_STEPS_MEDIUM = 300
MAX_STEPS_HARD = 500

# Wall-clock timeout per task (seconds). Total budget is 20 min = 1200s.
# Split conservatively: easy 180s, medium 360s, hard 540s (leaves 120s margin).
WALL_CLOCK_EASY = 180
WALL_CLOCK_MEDIUM = 360
WALL_CLOCK_HARD = 540

TEMPERATURE = 0.1
MAX_TOKENS = 64
SUCCESS_SCORE_THRESHOLD = 0.3  # normalised score in [0, 1]

# ---------------------------------------------------------------------------
# Per-task normalization offsets — MUST match each grader's theoretical_min
# easy_grader  uses -50.0
# medium_grader uses -80.0
# hard_grader  uses -120.0
# ---------------------------------------------------------------------------
TASK_OFFSETS: Dict[str, float] = {
    "easy": 50.0,
    "medium": 80.0,
    "hard": 120.0,
}


# ---------------------------------------------------------------------------
# Structured Logging Helpers
# ---------------------------------------------------------------------------

def log_start(task: str, env: str, model: str) -> None:
    print(f"[START] task={task} env={env} model={model}", flush=True)


def log_step(step: int, action: str, reward: float, done: bool, error: Optional[str]) -> None:
    error_val = error if error else "null"
    done_val = str(done).lower()
    print(
        f"[STEP] step={step} action={action} reward={reward:.2f} done={done_val} error={error_val}",
        flush=True,
    )


def log_end(success: bool, steps: int, score: float, rewards: List[float]) -> None:
    rewards_str = ",".join(f"{r:.2f}" for r in rewards)
    print(
        f"[END] success={str(success).lower()} steps={steps} score={score:.3f} rewards={rewards_str}",
        flush=True,
    )


# ---------------------------------------------------------------------------
# LLM Agent
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = textwrap.dedent("""
    You are a delivery route optimizer for a fleet of vehicles.
    At each step you must choose which delivery to pursue next.
    Consider: distance, deadline urgency, traffic delays, fuel remaining, and package priority.
    Reply with ONLY a JSON object: {"delivery_id": <int>}
    Do not include any other text.
""").strip()


def build_user_prompt(state: State) -> str:
    """Build a concise prompt describing the current environment state."""
    deliveries_info = []
    for d in state.deliveries:
        if d.status in (DeliveryStatus.DELIVERED, DeliveryStatus.FAILED):
            continue
        deliveries_info.append({
            "id": d.delivery_id,
            "pickup": [round(d.pickup_x, 1), round(d.pickup_y, 1)],
            "dropoff": [round(d.dropoff_x, 1), round(d.dropoff_y, 1)],
            "deadline": d.deadline,
            "priority": d.priority,
            "picked_up": d.picked_up,
            "traffic_delay": d.traffic_delay,
            "weight": d.weight,
        })

    if not deliveries_info:
        return "No pending deliveries."

    vehicles_info = []
    for v in state.vehicles:
        vehicles_info.append({
            "id": v.vehicle_id,
            "location": [round(v.x, 1), round(v.y, 1)],
            "fuel": round(v.fuel, 1),
        })

    return (
        f"Vehicle(s): {json.dumps(vehicles_info)}\n"
        f"Time: {round(state.time, 1)} / {round(state.max_time, 1)}\n"
        f"Pending deliveries:\n{json.dumps(deliveries_info, indent=2)}\n\n"
        "Choose the best delivery_id. Reply ONLY with JSON: {\"delivery_id\": <int>}"
    )


def get_llm_action(client: OpenAI, state: State) -> Optional[Action]:
    """Query the LLM to pick the next delivery."""
    user_prompt = build_user_prompt(state)
    if user_prompt == "No pending deliveries.":
        return None

    try:
        completion = client.chat.completions.create(
            model=MODEL_NAME,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_prompt},
            ],
            temperature=TEMPERATURE,
            max_tokens=MAX_TOKENS,
            stream=False,
        )
        text = (completion.choices[0].message.content or "").strip()
        if "{" in text:
            json_str = text[text.index("{"):text.rindex("}") + 1]
            data = json.loads(json_str)
            return Action(
                delivery_id=int(data["delivery_id"]),
                vehicle_id=int(data.get("vehicle_id", 0)),
            )
    except Exception:
        pass

    # Fallback to deadline-aware heuristic
    return heuristic_action(state)


# ---------------------------------------------------------------------------
# Heuristic Fallback
# ---------------------------------------------------------------------------

def heuristic_action(state: State) -> Optional[Action]:
    """Deadline-aware + nearest-pending heuristic fallback."""
    vx, vy = state.vehicle_location
    best_id: Optional[int] = None
    best_score = float("inf")

    for d in state.deliveries:
        if d.status in (DeliveryStatus.DELIVERED, DeliveryStatus.FAILED):
            continue
        if d.picked_up:
            tx, ty = d.dropoff_x, d.dropoff_y
        else:
            tx, ty = d.pickup_x, d.pickup_y

        dist = math.hypot(tx - vx, ty - vy)
        time_left = max(0.1, d.deadline - state.time)
        score = dist / (d.priority + 0.1) + time_left * 0.3
        if d.picked_up:
            score -= 5.0  # prefer finishing in-transit deliveries

        if score < best_score:
            best_score = score
            best_id = d.delivery_id

    if best_id is not None:
        return Action(delivery_id=best_id)
    return None


# ---------------------------------------------------------------------------
# Normalise Score — uses per-task offset to match each grader exactly
# ---------------------------------------------------------------------------

def normalise_score(total_reward: float, env: DeliveryEnv, task_name: str) -> float:
    """
    Normalise accumulated reward to [0.0, 1.0].

    The offset constant MUST match the corresponding grader:
      easy_grader   -> offset 50.0
      medium_grader -> offset 80.0
      hard_grader   -> offset 120.0
    """
    cfg = env.config
    final_state = env.state()
    total_priority = sum(d.priority for d in final_state.deliveries)
    num_d = len(final_state.deliveries)

    offset = TASK_OFFSETS.get(task_name, 120.0)

    theoretical_max = cfg.delivery_reward * total_priority + 2.0 * num_d
    theoretical_min = -(cfg.late_penalty_factor * cfg.max_time * num_d) - offset

    score = (total_reward - theoretical_min) / (theoretical_max - theoretical_min + 1e-8)
    return round(max(0.0, min(1.0, score)), 4)


# ---------------------------------------------------------------------------
# Run One Task Episode
# ---------------------------------------------------------------------------

def run_task(
    task_name: str,
    env: DeliveryEnv,
    client: Optional[OpenAI],
    max_steps: int,
    wall_clock_limit: int,
) -> float:
    """
    Run a single task episode with structured [START]/[STEP]/[END] logging.
    Returns the normalised score in [0.0, 1.0].

    Exits the step loop early if wall_clock_limit seconds have elapsed to
    stay within the 20-minute infra budget.
    """
    rewards: List[float] = []
    steps_taken = 0
    score = 0.0
    success = False
    episode_start = time.monotonic()

    log_start(task=task_name, env=BENCHMARK, model=MODEL_NAME)

    try:
        state = env.reset()

        for step in range(1, max_steps + 1):
            if state.done:
                break

            # Wall-clock guard — emit END cleanly if we're out of time
            elapsed = time.monotonic() - episode_start
            if elapsed >= wall_clock_limit:
                print(
                    f"[STEP] step={step} action=timeout reward=0.00 done=true error=wall_clock_limit_reached",
                    flush=True,
                )
                break

            # Get action from LLM or heuristic
            if client is not None:
                action = get_llm_action(client, state)
            else:
                action = heuristic_action(state)

            if action is None:
                break

            action_str = f"deliver({action.delivery_id})"
            error: Optional[str] = None

            try:
                state, reward, done, info = env.step(action)
            except Exception as e:
                reward = 0.0
                done = True
                error = str(e)

            rewards.append(reward)
            steps_taken = step

            log_step(step=step, action=action_str, reward=reward, done=done, error=error)

            if done:
                break

        # Compute normalised score using task-specific offset
        total_reward = sum(rewards)
        score = normalise_score(total_reward, env, task_name)
        success = score >= SUCCESS_SCORE_THRESHOLD

    except Exception as exc:
        # Always emit [END] even on exception
        error_msg = str(exc)
        print(f"[STEP] step={steps_taken + 1} action=error reward=0.00 done=true error={error_msg}", flush=True)

    finally:
        log_end(success=success, steps=steps_taken, score=score, rewards=rewards)

    return score


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    # Build OpenAI client
    client: Optional[OpenAI] = None
    if API_KEY:
        client = OpenAI(base_url=API_BASE_URL, api_key=API_KEY)

    # Run all 3 tasks
    tasks = [
        ("easy",   easy_task(),   MAX_STEPS_EASY,   WALL_CLOCK_EASY),
        ("medium", medium_task(), MAX_STEPS_MEDIUM,  WALL_CLOCK_MEDIUM),
        ("hard",   hard_task(),   MAX_STEPS_HARD,    WALL_CLOCK_HARD),
    ]

    scores: Dict[str, float] = {}
    for task_name, env, max_steps, wall_clock in tasks:
        score = run_task(task_name, env, client, max_steps, wall_clock)
        scores[task_name] = score

    # Validate all scores in [0, 1]
    for name, s in scores.items():
        assert 0.0 <= s <= 1.0, f"{name} score {s} out of [0,1] range!"


if __name__ == "__main__":
    main()